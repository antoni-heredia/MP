/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// CURSO 2016-2017
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// producto.cpp
//
/***************************************************************************/

#include "producto.h"
using namespace std;

/*********************************************************************/

int multiplica (int a, int b)
{
   return (a*b); 
}

/*********************************************************************/

int divide (int a, int b)
{
   return (a/b); 
}
